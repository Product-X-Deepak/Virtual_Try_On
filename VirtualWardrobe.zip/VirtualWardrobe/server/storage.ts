import { 
  Product, 
  InsertProduct, 
  UserMeasurements, 
  InsertUserMeasurements,
  UserPhoto,
  InsertUserPhoto,
  VirtualModel,
  InsertVirtualModel,
  SizeRecommendation,
  InsertSizeRecommendation
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getProductSuggestions(productId?: number): Promise<Product[]>;
  
  // User Measurements
  saveUserMeasurements(measurements: InsertUserMeasurements): Promise<UserMeasurements>;
  getUserMeasurements(userId: string): Promise<UserMeasurements | undefined>;
  
  // User Photos
  saveUserPhoto(photo: InsertUserPhoto): Promise<UserPhoto>;
  getUserPhoto(userId: string): Promise<UserPhoto | undefined>;
  
  // Virtual Models
  saveVirtualModel(model: InsertVirtualModel): Promise<VirtualModel>;
  getVirtualModel(userId: string): Promise<VirtualModel | undefined>;
  
  // Size Recommendations
  getSizeRecommendation(userId: string, productId: number): Promise<SizeRecommendation | undefined>;
  saveSizeRecommendation(recommendation: InsertSizeRecommendation): Promise<SizeRecommendation>;
}

// In-memory implementation
export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private userMeasurements: Map<string, UserMeasurements>;
  private userPhotos: Map<string, UserPhoto>;
  private virtualModels: Map<string, VirtualModel>;
  private sizeRecommendations: Map<string, SizeRecommendation>; // key is `${userId}-${productId}`
  
  private productIdCounter: number;
  private measurementsIdCounter: number;
  private photoIdCounter: number;
  private modelIdCounter: number;
  private recommendationIdCounter: number;

  constructor() {
    this.products = new Map();
    this.userMeasurements = new Map();
    this.userPhotos = new Map();
    this.virtualModels = new Map();
    this.sizeRecommendations = new Map();
    
    this.productIdCounter = 1;
    this.measurementsIdCounter = 1;
    this.photoIdCounter = 1;
    this.modelIdCounter = 1;
    this.recommendationIdCounter = 1;
    
    // Initialize with sample products
    this.initializeSampleProducts();
  }

  private initializeSampleProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Casual Blue Tee",
        price: "$29.99",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "100% Cotton, Machine washable",
        category: "tops"
      },
      {
        name: "Classic White Blouse",
        price: "$39.99",
        image: "https://images.unsplash.com/photo-1519568470290-c0c1fbfff16f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "100% Cotton, Machine washable",
        category: "tops"
      },
      {
        name: "Essential Black Tee",
        price: "$24.99",
        image: "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "95% Cotton, 5% Elastane, Machine washable",
        category: "tops"
      },
      {
        name: "Striped Button-Up",
        price: "$49.99",
        image: "https://images.unsplash.com/photo-1554568218-0f1715e72254?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "100% Cotton, Machine washable",
        category: "tops"
      },
      {
        name: "Slim Fit Jeans",
        price: "$59.99",
        image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "98% Cotton, 2% Elastane, Machine washable",
        category: "bottoms"
      },
      {
        name: "Silver Pendant Necklace",
        price: "$29.99",
        image: "https://images.unsplash.com/photo-1613987876445-fcb353cd8e27?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "Sterling silver, Nickel-free",
        category: "accessories"
      },
      {
        name: "Classic White Sneakers",
        price: "$79.99",
        image: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "Leather upper, Rubber sole",
        category: "accessories"
      },
      {
        name: "Brown Leather Belt",
        price: "$34.99",
        image: "https://images.unsplash.com/photo-1544816155-12df9643f363?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=800&q=80",
        description: "100% Genuine leather",
        category: "accessories"
      }
    ];

    sampleProducts.forEach(product => {
      const id = this.productIdCounter++;
      this.products.set(id, { ...product, id });
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category === category
    );
  }

  async getProductSuggestions(productId?: number): Promise<Product[]> {
    // For now, just return some random products as suggestions
    const allProducts = Array.from(this.products.values());
    
    // If productId is provided, exclude that product from suggestions
    let availableProducts = productId
      ? allProducts.filter(p => p.id !== productId)
      : allProducts;
    
    // Shuffle and return up to 4 products
    return this.shuffleArray(availableProducts).slice(0, 4);
  }

  // Helper method to shuffle an array
  private shuffleArray<T>(array: T[]): T[] {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
  }

  // User Measurements
  async saveUserMeasurements(measurements: InsertUserMeasurements): Promise<UserMeasurements> {
    const id = this.measurementsIdCounter++;
    
    // Create a properly typed UserMeasurements object
    const userMeasurements: UserMeasurements = {
      id,
      userId: measurements.userId,
      gender: measurements.gender,
      height: measurements.height,
      weight: measurements.weight,
      chest: measurements.chest,
      waist: measurements.waist,
      hips: measurements.hips,
      createdAt: measurements.createdAt,
      // Handle optional fields
      age: measurements.age === undefined ? null : measurements.age,
      shoulderWidth: measurements.shoulderWidth === undefined ? null : measurements.shoulderWidth,
      armLength: measurements.armLength === undefined ? null : measurements.armLength,
      inseam: measurements.inseam === undefined ? null : measurements.inseam
    };
    
    this.userMeasurements.set(measurements.userId, userMeasurements);
    return userMeasurements;
  }

  async getUserMeasurements(userId: string): Promise<UserMeasurements | undefined> {
    return this.userMeasurements.get(userId);
  }

  // User Photos
  async saveUserPhoto(photo: InsertUserPhoto): Promise<UserPhoto> {
    const id = this.photoIdCounter++;
    const userPhoto: UserPhoto = { ...photo, id };
    this.userPhotos.set(photo.userId, userPhoto);
    return userPhoto;
  }

  async getUserPhoto(userId: string): Promise<UserPhoto | undefined> {
    return this.userPhotos.get(userId);
  }

  // Virtual Models
  async saveVirtualModel(model: InsertVirtualModel): Promise<VirtualModel> {
    const id = this.modelIdCounter++;
    const virtualModel: VirtualModel = { ...model, id };
    this.virtualModels.set(model.userId, virtualModel);
    return virtualModel;
  }

  async getVirtualModel(userId: string): Promise<VirtualModel | undefined> {
    return this.virtualModels.get(userId);
  }

  // Size Recommendations
  async getSizeRecommendation(userId: string, productId: number): Promise<SizeRecommendation | undefined> {
    const key = `${userId}-${productId}`;
    return this.sizeRecommendations.get(key);
  }

  async saveSizeRecommendation(recommendation: InsertSizeRecommendation): Promise<SizeRecommendation> {
    const id = this.recommendationIdCounter++;
    const sizeRecommendation: SizeRecommendation = { ...recommendation, id };
    const key = `${recommendation.userId}-${recommendation.productId}`;
    this.sizeRecommendations.set(key, sizeRecommendation);
    return sizeRecommendation;
  }
}

export const storage = new MemStorage();
