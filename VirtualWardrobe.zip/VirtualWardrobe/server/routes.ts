import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserMeasurementsSchema, 
  insertUserPhotoSchema,
  insertVirtualModelSchema,
  insertSizeRecommendationSchema
} from "@shared/schema";
import { z } from "zod";
import { randomUUID } from "crypto";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import sharp from "sharp";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Set up multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB
  },
});

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, "../uploads");
fs.mkdir(uploadsDir, { recursive: true }).catch(console.error);

export async function registerRoutes(app: Express): Promise<Server> {
  // Session-based user ID for demo purposes
  app.use((req, res, next) => {
    if (!req.headers["user-id"]) {
      req.headers["user-id"] = randomUUID();
    }
    next();
  });

  // Get all products
  app.get("/api/products", async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get products by category
  app.get("/api/products/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products by category" });
    }
  });

  // Get product suggestions
  app.get("/api/products/suggestions", async (req: Request, res: Response) => {
    try {
      const productId = req.query.productId ? parseInt(req.query.productId as string) : undefined;
      const suggestions = await storage.getProductSuggestions(productId);
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product suggestions" });
    }
  });

  // Get a specific product
  app.get("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProductById(id);
      
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Upload photo for try-on
  app.post("/api/upload-photo", upload.single("photo"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No photo uploaded" });
      }

      const userId = req.headers["user-id"] as string;
      const filename = `${userId}-${Date.now()}.jpg`;
      const photoPath = path.join(uploadsDir, filename);
      
      // Process image with Sharp
      await sharp(req.file.buffer)
        .resize(800, null, { fit: "inside" })
        .jpeg({ quality: 80 })
        .toFile(photoPath);
      
      // Save photo record
      const userPhoto = await storage.saveUserPhoto({
        userId,
        photoPath: filename,
        createdAt: new Date().toISOString(),
      });
      
      // Create a virtual model based on the photo
      const virtualModel = await storage.saveVirtualModel({
        userId,
        modelPath: filename,
        modelType: "photo",
        createdAt: new Date().toISOString(),
      });
      
      res.json({ success: true, photoPath: filename });
    } catch (error) {
      console.error("Error uploading photo:", error);
      res.status(500).json({ message: "Failed to upload photo" });
    }
  });

  // Save measurements
  app.post("/api/measurements", async (req: Request, res: Response) => {
    try {
      const userId = req.headers["user-id"] as string;
      
      // Convert string inputs to numbers
      const formData = {
        ...req.body,
        age: req.body.age ? parseInt(req.body.age) : null,
        height: parseInt(req.body.height),
        weight: parseInt(req.body.weight),
        chest: parseInt(req.body.chest),
        waist: parseInt(req.body.waist),
        hips: parseInt(req.body.hips),
        shoulderWidth: req.body.shoulderWidth ? parseInt(req.body.shoulderWidth) : null,
        armLength: req.body.armLength ? parseInt(req.body.armLength) : null,
        inseam: req.body.inseam ? parseInt(req.body.inseam) : null,
      };
      
      const measurementsData = {
        ...formData,
        userId,
        createdAt: new Date().toISOString(),
      };
      
      // Validate measurements data
      const validatedData = insertUserMeasurementsSchema.parse(measurementsData);
      
      // Save to storage
      const savedMeasurements = await storage.saveUserMeasurements(validatedData);
      
      // Create a virtual model based on measurements
      const virtualModel = await storage.saveVirtualModel({
        userId,
        modelPath: "avatar-" + userId + ".jpg", // Placeholder for a generated avatar
        modelType: "measurements",
        createdAt: new Date().toISOString(),
      });
      
      res.json(savedMeasurements);
    } catch (error) {
      console.error("Error saving measurements:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid measurement data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save measurements" });
    }
  });

  // Combined approach (photo + measurements)
  app.post("/api/combined-approach", upload.single("photo"), async (req: Request, res: Response) => {
    try {
      const userId = req.headers["user-id"] as string;
      
      // Save photo if uploaded
      let photoPath = "";
      if (req.file) {
        const filename = `${userId}-${Date.now()}.jpg`;
        photoPath = path.join(uploadsDir, filename);
        
        await sharp(req.file.buffer)
          .resize(800, null, { fit: "inside" })
          .jpeg({ quality: 80 })
          .toFile(photoPath);
        
        await storage.saveUserPhoto({
          userId,
          photoPath: filename,
          createdAt: new Date().toISOString(),
        });
      }
      
      // Save measurements
      const formData = {
        gender: req.body.gender,
        height: parseInt(req.body.height),
        weight: parseInt(req.body.weight),
        chest: parseInt(req.body.chest),
        waist: parseInt(req.body.waist),
        hips: parseInt(req.body.hips),
        userId,
        createdAt: new Date().toISOString(),
      };
      
      const savedMeasurements = await storage.saveUserMeasurements(formData);
      
      // Create combined virtual model
      const virtualModel = await storage.saveVirtualModel({
        userId,
        modelPath: photoPath ? path.basename(photoPath) : "avatar-" + userId + ".jpg",
        modelType: "combined",
        createdAt: new Date().toISOString(),
      });
      
      res.json({ success: true, measurements: savedMeasurements, photoUploaded: !!photoPath });
    } catch (error) {
      console.error("Error processing combined approach:", error);
      res.status(500).json({ message: "Failed to process combined data" });
    }
  });

  // Get virtual model
  app.get("/api/virtual-model", async (req: Request, res: Response) => {
    try {
      const userId = req.headers["user-id"] as string;
      let virtualModel = await storage.getVirtualModel(userId);
      
      // If no model exists, create a default one
      if (!virtualModel) {
        // Create a default virtual model for the user
        virtualModel = await storage.saveVirtualModel({
          userId,
          modelPath: "placeholder.svg", // Use SVG placeholder image
          modelType: "default",
          createdAt: new Date().toISOString(),
        });
      }
      
      // Generate image URL
      const imageUrl = `/uploads/${virtualModel.modelPath}`;
      
      res.json({
        id: virtualModel.id,
        userId: virtualModel.userId,
        modelType: virtualModel.modelType,
        createdAt: virtualModel.createdAt,
        imageUrl: imageUrl
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch virtual model" });
    }
  });

  // Get size recommendation
  app.get("/api/size-recommendation", async (req: Request, res: Response) => {
    try {
      const userId = req.headers["user-id"] as string;
      const productId = parseInt(req.query.productId as string);
      
      if (!productId) {
        return res.status(400).json({ message: "Product ID is required" });
      }
      
      // Check if there's an existing recommendation
      let recommendation = await storage.getSizeRecommendation(userId, productId);
      
      // If no recommendation exists, generate one
      if (!recommendation) {
        // Get user measurements
        let measurements = await storage.getUserMeasurements(userId);
        
        // If no measurements exist, create default measurements
        if (!measurements) {
          // Create default measurements for demo purposes
          measurements = await storage.saveUserMeasurements({
            userId,
            gender: "female", // Default to female
            height: 170, // Average height in cm
            weight: 65, // Average weight in kg
            chest: 95, // Average chest size
            waist: 80, // Average waist size
            hips: 95, // Average hip size
            createdAt: new Date().toISOString(),
            age: 30,
            shoulderWidth: 40,
            armLength: 60,
            inseam: 80
          });
        }
        
        // Simple algorithm to determine size based on measurements
        let size = "M"; // Default size
        const { gender, chest, waist } = measurements;
        
        if (gender === "female") {
          if (chest < 85) size = "XS";
          else if (chest < 90) size = "S";
          else if (chest < 95) size = "M";
          else if (chest < 100) size = "L";
          else if (chest < 105) size = "XL";
          else size = "XXL";
        } else {
          if (chest < 90) size = "XS";
          else if (chest < 95) size = "S";
          else if (chest < 100) size = "M";
          else if (chest < 105) size = "L";
          else if (chest < 110) size = "XL";
          else size = "XXL";
        }
        
        // Save the recommendation
        recommendation = await storage.saveSizeRecommendation({
          userId,
          productId,
          size,
          confidence: 85, // Confidence level
          createdAt: new Date().toISOString(),
        });
      }
      
      res.json(recommendation);
    } catch (error) {
      console.error("Size recommendation error:", error);
      res.status(500).json({ message: "Failed to get size recommendation" });
    }
  });

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    const filePath = path.join(uploadsDir, path.basename(req.path));
    res.sendFile(filePath, (err) => {
      if (err) {
        // If file doesn't exist, serve a default placeholder image
        res.sendFile(path.join(__dirname, "../uploads/placeholder.svg"), (placeholderErr) => {
          if (placeholderErr) {
            res.status(404).json({ message: "Image not found" });
          }
        });
      }
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
