import { useState } from "react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { User, ShoppingBag, Search, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navbar() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <h1 className="font-poppins font-bold text-[#2C3E50] text-2xl cursor-pointer">
                  FitVirtual
                </h1>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center space-x-8">
              <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                Women
              </Link>
              <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                Men
              </Link>
              <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                Accessories
              </Link>
              <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                Sale
              </Link>
            </div>
          </div>
          <div className="flex items-center">
            <div className="hidden md:block">
              <div className="relative">
                <Input
                  className="rounded-full py-2 pl-4 pr-10 w-64 bg-[#F8F9FA] focus:ring-[#3498DB]"
                  placeholder="Search for items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="absolute right-3 top-1/2 -translate-y-1/2">
                  <Search className="h-5 w-5 text-[#34495E]" />
                </button>
              </div>
            </div>
            <div className="flex items-center ml-4 space-x-4">
              <button className="text-[#34495E] hover:text-[#3498DB]">
                <User className="h-6 w-6" />
              </button>
              <button className="text-[#34495E] hover:text-[#3498DB]">
                <ShoppingBag className="h-6 w-6" />
              </button>
              <Sheet>
                <SheetTrigger asChild>
                  <button className="block md:hidden text-[#34495E]">
                    <Menu className="h-6 w-6" />
                  </button>
                </SheetTrigger>
                <SheetContent>
                  <div className="flex flex-col gap-6 py-4">
                    <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                      Women
                    </Link>
                    <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                      Men
                    </Link>
                    <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                      Accessories
                    </Link>
                    <Link href="#" className="text-[#2C3E50] hover:text-[#3498DB] font-medium">
                      Sale
                    </Link>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
