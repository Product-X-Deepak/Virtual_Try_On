import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useDropzone } from "react-dropzone";
import { Image, Upload } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface PhotoUploadProps {
  onContinue: () => void;
}

export default function PhotoUpload({ onContinue }: PhotoUploadProps) {
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const { toast } = useToast();
  
  const photoUploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("photo", file);
      return apiRequest("POST", "/api/upload-photo", formData);
    },
    onSuccess: () => {
      toast({
        title: "Photo uploaded successfully",
        description: "You can now continue to the virtual try-on.",
      });
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      setPhoto(file);
      
      // Create preview URL
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1
  });

  const handleContinue = () => {
    if (photo) {
      photoUploadMutation.mutate(photo);
      onContinue();
    } else {
      toast({
        title: "No photo selected",
        description: "Please upload a photo before continuing.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-[#2C3E50] text-center mb-8">
          Upload Your Photo
        </h2>

        <div className="max-w-xl mx-auto bg-[#F8F9FA] rounded-xl shadow-md p-6">
          <div className="mb-6">
            <div {...getRootProps()} className="flex items-center justify-center w-full">
              <label className="flex flex-col w-full h-64 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                {preview ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <img 
                      src={preview} 
                      alt="Preview" 
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center pt-7">
                    {isDragActive ? (
                      <Upload className="w-12 h-12 text-gray-400" />
                    ) : (
                      <Image className="w-12 h-12 text-gray-400" />
                    )}
                    <p className="pt-1 text-sm tracking-wider text-gray-400">
                      {isDragActive
                        ? "Drop your photo here"
                        : "Upload a full-body photo"}
                    </p>
                  </div>
                )}
                <input {...getInputProps()} />
              </label>
            </div>
          </div>

          <div className="text-center">
            <p className="text-sm text-gray-500 mb-4">
              Please upload a well-lit photo with your entire body visible, standing straight with arms slightly away from your body.
            </p>
            <Button 
              className="px-8 py-2 bg-[#3498DB] text-white font-medium rounded-full hover:bg-blue-600 transition-colors"
              onClick={handleContinue}
              disabled={!photo || photoUploadMutation.isPending}
            >
              {photoUploadMutation.isPending ? "Uploading..." : "Continue"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
