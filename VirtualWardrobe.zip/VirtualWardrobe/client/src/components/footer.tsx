import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { FaTwitter, FaInstagram, FaFacebook, FaYoutube } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-[#2C3E50] text-white py-12 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-poppins font-semibold mb-4">FitVirtual</h3>
            <p className="text-sm text-gray-300">
              Try before you buy with our innovative virtual fitting room technology.
            </p>
          </div>
          <div>
            <h4 className="text-md font-poppins font-medium mb-4">Shop</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <Link href="#" className="hover:text-white">
                  Women
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  Men
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  Accessories
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  Sale
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-md font-poppins font-medium mb-4">Help</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <Link href="#" className="hover:text-white">
                  How it Works
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  Sizing Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-white">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-md font-poppins font-medium mb-4">Stay Connected</h4>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="text-gray-300 hover:text-white">
                <FaTwitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <FaInstagram className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <FaFacebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <FaYoutube className="h-6 w-6" />
              </a>
            </div>
            <h4 className="text-md font-poppins font-medium mb-2">Subscribe for Updates</h4>
            <div className="flex">
              <Input
                type="email"
                placeholder="Your email"
                className="rounded-l-md rounded-r-none text-[#2C3E50] focus:ring-[#3498DB]"
              />
              <Button className="bg-[#3498DB] hover:bg-blue-600 rounded-l-none">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-700 text-sm text-gray-400 text-center">
          <p>&copy; {new Date().getFullYear()} FitVirtual. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
