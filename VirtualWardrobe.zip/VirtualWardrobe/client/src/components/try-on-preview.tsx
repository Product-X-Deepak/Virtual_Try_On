import { useState } from "react";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCw, 
  ShoppingCart 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  TransformWrapper, 
  TransformComponent 
} from "react-zoom-pan-pinch";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
  description: string;
  category: string;
}

interface TryOnPreviewProps {
  selectedItem: Product | null;
}

export default function TryOnPreview({ 
  selectedItem 
}: TryOnPreviewProps) {
  const { toast } = useToast();
  
  // Define types for the response data
  interface VirtualModelResponse {
    id: number;
    userId: string;
    modelPath: string;
    modelType: string;
    createdAt: string;
    imageUrl: string; // This is added by the server
  }
  
  interface SizeRecommendationResponse {
    id: number;
    userId: string;
    productId: number;
    size: string;
    confidence: number;
    createdAt: string;
  }

  // Get virtual model from API
  const { data: virtualModel } = useQuery<VirtualModelResponse>({
    queryKey: ["/api/virtual-model"],
    // Always enable this query, even if no item is selected
    enabled: true,
  });

  // Get size recommendation
  const { data: sizeRecommendation } = useQuery<SizeRecommendationResponse>({
    queryKey: ["/api/size-recommendation"],
    queryFn: async () => {
      if (!selectedItem) return null;
      // Use product ID directly (it's already a number)
      const productId = selectedItem.id;
      
      return fetch(`/api/size-recommendation?productId=${productId}`).then(res => {
        if (!res.ok) throw new Error('Failed to get size recommendation');
        return res.json();
      });
    },
    enabled: !!selectedItem,
  });

  const sizes = ["XS", "S", "M", "L", "XL", "XXL"];
  
  // State for transform controls
  const [transformApi, setTransformApi] = useState<any>(null);
  
  const handleZoomIn = () => {
    if (transformApi) {
      transformApi.zoomIn();
    }
  };
  
  const handleZoomOut = () => {
    if (transformApi) {
      transformApi.zoomOut();
    }
  };
  
  const handleReset = () => {
    if (transformApi) {
      transformApi.resetTransform();
    }
  };
  
  const handleAddToCart = () => {
    toast({
      title: "Added to cart",
      description: `${selectedItem?.name} has been added to your cart.`,
    });
  };

  return (
    <div className="bg-[#F8F9FA] rounded-xl shadow-md p-6 lg:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-poppins font-medium text-[#2C3E50]">
          Try-On Preview
        </h3>
        <div className="flex space-x-2">
          <button 
            className="p-2 text-gray-500 hover:text-[#3498DB] bg-white rounded-full shadow-sm"
            onClick={handleZoomIn}
            aria-label="Zoom in"
          >
            <ZoomIn className="h-5 w-5" />
          </button>
          <button 
            className="p-2 text-gray-500 hover:text-[#3498DB] bg-white rounded-full shadow-sm"
            onClick={handleZoomOut}
            aria-label="Zoom out"
          >
            <ZoomOut className="h-5 w-5" />
          </button>
          <button 
            className="p-2 text-gray-500 hover:text-[#3498DB] bg-white rounded-full shadow-sm"
            onClick={handleReset}
            aria-label="Reset view"
          >
            <RotateCw className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="relative" style={{ height: "500px" }}>
          {virtualModel ? (
            <TransformWrapper
              initialScale={1}
              initialPositionX={0}
              initialPositionY={0}
              doubleClick={{ disabled: true }}
              onInit={(instance) => setTransformApi(instance)}
            >
              <TransformComponent>
                <div className="relative h-full w-full">
                  <img
                    src={virtualModel.imageUrl}
                    className="h-full w-full object-contain"
                    alt="Virtual model"
                  />
                  {!selectedItem && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white text-xl font-semibold">
                      Click "Try On" on any product to get started
                    </div>
                  )}
                </div>
              </TransformComponent>
            </TransformWrapper>
          ) : (
            <div className="h-full w-full flex items-center justify-center text-gray-400">
              Loading virtual model...
            </div>
          )}
        </div>
      </div>

      {/* Size Recommendation & Product Details */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white p-4 rounded-lg shadow-sm">
          <h4 className="font-poppins font-medium text-[#2C3E50] mb-2">Size Recommendation</h4>
          <div className="flex space-x-2 mb-3">
            {sizes.map((size) => (
              <span
                key={size}
                className={`px-3 py-1 text-xs rounded-full ${
                  sizeRecommendation?.size === size
                    ? "bg-[#E74C3C] text-white font-medium"
                    : "bg-gray-200 text-gray-600"
                }`}
              >
                {size}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-600">
            {sizeRecommendation ? (
              <>
                Based on your measurements, we recommend size{" "}
                <strong>{sizeRecommendation.size}</strong> for this item.
              </>
            ) : (
              "Select an item to see size recommendations."
            )}
          </p>
        </Card>

        <Card className="bg-white p-4 rounded-lg shadow-sm">
          <h4 className="font-poppins font-medium text-[#2C3E50] mb-2">Current Item</h4>
          {selectedItem ? (
            <div>
              <p className="text-sm text-gray-600">
                <strong>{selectedItem.name}</strong>
              </p>
              <p className="text-sm text-gray-600">{selectedItem.price}</p>
              <p className="text-sm text-gray-600 mt-2">{selectedItem.description}</p>
              <div className="mt-3">
                <Button 
                  className="px-4 py-1.5 bg-[#E74C3C] text-white text-sm rounded-full hover:bg-red-600 transition-colors"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="h-4 w-4 mr-1" />
                  Add to Cart
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-600">
              Select an item to see details.
            </p>
          )}
        </Card>
      </div>
    </div>
  );
}
