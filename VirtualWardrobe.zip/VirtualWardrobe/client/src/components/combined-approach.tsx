import { useState, useCallback } from "react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Image, Upload } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CombinedApproachProps {
  onContinue: () => void;
}

const combinedSchema = z.object({
  photo: z.any().optional(),
  gender: z.string().min(1, "Please select your gender"),
  height: z.string().min(1, "Please enter your height"),
  weight: z.string().min(1, "Please enter your weight"),
  chest: z.string().min(1, "Please enter your chest measurement"),
  waist: z.string().min(1, "Please enter your waist measurement"),
  hips: z.string().min(1, "Please enter your hip measurement"),
});

type CombinedFormValues = z.infer<typeof combinedSchema>;

export default function CombinedApproach({ onContinue }: CombinedApproachProps) {
  const [photo, setPhoto] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<CombinedFormValues>({
    resolver: zodResolver(combinedSchema),
    defaultValues: {
      gender: "",
      height: "",
      weight: "",
      chest: "",
      waist: "",
      hips: "",
    },
  });

  const combinedMutation = useMutation({
    mutationFn: async (data: CombinedFormValues & { photo?: File }) => {
      const formData = new FormData();
      
      if (data.photo) {
        formData.append('photo', data.photo);
      }
      
      formData.append('gender', data.gender);
      formData.append('height', data.height);
      formData.append('weight', data.weight);
      formData.append('chest', data.chest);
      formData.append('waist', data.waist);
      formData.append('hips', data.hips);
      
      return apiRequest("POST", "/api/combined-approach", formData);
    },
    onSuccess: () => {
      toast({
        title: "Data saved successfully",
        description: "Your photo and measurements have been saved.",
      });
      onContinue();
    },
    onError: (error) => {
      toast({
        title: "Error saving data",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      setPhoto(file);
      
      // Create preview URL
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      
      return () => URL.revokeObjectURL(objectUrl);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1
  });

  const onSubmit = (data: CombinedFormValues) => {
    combinedMutation.mutate({ ...data, photo });
  };

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-[#2C3E50] text-center mb-8">
          Photo & Measurements
        </h2>

        <div className="max-w-2xl mx-auto bg-[#F8F9FA] rounded-xl shadow-md p-6">
          <div className="mb-8">
            <h3 className="text-lg font-poppins font-medium text-[#2C3E50] mb-4">
              Upload Your Photo
            </h3>
            <div {...getRootProps()} className="flex items-center justify-center w-full">
              <label className="flex flex-col w-full h-48 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                {preview ? (
                  <div className="h-full w-full flex items-center justify-center">
                    <img 
                      src={preview} 
                      alt="Preview" 
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center pt-7">
                    {isDragActive ? (
                      <Upload className="w-10 h-10 text-gray-400" />
                    ) : (
                      <Image className="w-10 h-10 text-gray-400" />
                    )}
                    <p className="pt-1 text-sm tracking-wider text-gray-400">
                      {isDragActive
                        ? "Drop your photo here"
                        : "Upload a full-body photo"}
                    </p>
                  </div>
                )}
                <input {...getInputProps()} />
              </label>
            </div>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Information */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-poppins font-medium text-[#2C3E50] mb-4">
                  Basic Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Gender</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="non-binary">Non-binary</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="height"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Height (cm)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Height in cm"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="weight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Weight (kg)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Weight in kg"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Key Measurements */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-poppins font-medium text-[#2C3E50] mb-4">
                  Key Measurements (in cm)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="chest"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Chest</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Chest"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="waist"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Waist</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Waist"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hips"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Hips</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Hips"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="md:col-span-2 text-center mt-4">
                <Button
                  type="submit"
                  className="px-8 py-2 bg-[#3498DB] text-white font-medium rounded-full hover:bg-blue-600 transition-colors"
                  disabled={combinedMutation.isPending}
                >
                  {combinedMutation.isPending ? "Processing..." : "Create Enhanced Model"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
