import { Image, Ruler, ShieldCheck } from "lucide-react";

interface TryOnOptionsProps {
  onSelect: (optionType: string) => void;
}

export default function TryOnOptions({ onSelect }: TryOnOptionsProps) {
  return (
    <div className="py-12 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-[#2C3E50] text-center mb-12">
          Choose Your Try-On Method
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Option 1: Photo Upload */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="p-6">
              <div className="w-16 h-16 bg-[#EBF5FB] rounded-full flex items-center justify-center mx-auto">
                <Image className="h-8 w-8 text-[#3498DB]" />
              </div>
              <h3 className="mt-4 text-xl font-poppins font-semibold text-[#2C3E50] text-center">
                Photo Upload
              </h3>
              <p className="mt-2 text-[#34495E] text-center">
                Upload your full-body photo and we'll overlay clothing items for a realistic preview.
              </p>
              <div className="mt-6 text-center">
                <button
                  onClick={() => onSelect("photo")}
                  className="px-6 py-2 bg-[#2C3E50] text-white font-medium rounded-full hover:bg-opacity-90 transition-colors"
                >
                  Select
                </button>
              </div>
            </div>
          </div>

          {/* Option 2: Measurements */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="p-6">
              <div className="w-16 h-16 bg-[#EBF5FB] rounded-full flex items-center justify-center mx-auto">
                <Ruler className="h-8 w-8 text-[#3498DB]" />
              </div>
              <h3 className="mt-4 text-xl font-poppins font-semibold text-[#2C3E50] text-center">
                Measurements
              </h3>
              <p className="mt-2 text-[#34495E] text-center">
                Enter your body measurements and we'll generate a virtual model matching your dimensions.
              </p>
              <div className="mt-6 text-center">
                <button
                  onClick={() => onSelect("measurements")}
                  className="px-6 py-2 bg-[#2C3E50] text-white font-medium rounded-full hover:bg-opacity-90 transition-colors"
                >
                  Select
                </button>
              </div>
            </div>
          </div>

          {/* Option 3: Combined Approach */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
            <div className="p-6">
              <div className="w-16 h-16 bg-[#EBF5FB] rounded-full flex items-center justify-center mx-auto">
                <ShieldCheck className="h-8 w-8 text-[#3498DB]" />
              </div>
              <h3 className="mt-4 text-xl font-poppins font-semibold text-[#2C3E50] text-center">
                Combined Approach
              </h3>
              <p className="mt-2 text-[#34495E] text-center">
                Upload a photo and provide measurements for the most accurate virtual try-on experience.
              </p>
              <div className="mt-6 text-center">
                <button
                  onClick={() => onSelect("combined")}
                  className="px-6 py-2 bg-[#2C3E50] text-white font-medium rounded-full hover:bg-opacity-90 transition-colors"
                >
                  Select
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
