import { useState } from "react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel 
} from "@/components/ui/form";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface MeasurementsFormProps {
  onContinue: () => void;
}

const measurementsSchema = z.object({
  gender: z.string().min(1, "Please select your gender"),
  age: z.string().min(1, "Please enter your age"),
  height: z.string().min(1, "Please enter your height"),
  weight: z.string().min(1, "Please enter your weight"),
  chest: z.string().min(1, "Please enter your chest measurement"),
  waist: z.string().min(1, "Please enter your waist measurement"),
  hips: z.string().min(1, "Please enter your hip measurement"),
  shoulderWidth: z.string().min(1, "Please enter your shoulder width"),
  armLength: z.string().min(1, "Please enter your arm length"),
  inseam: z.string().min(1, "Please enter your inseam length"),
});

type MeasurementsFormValues = z.infer<typeof measurementsSchema>;

export default function MeasurementsForm({ onContinue }: MeasurementsFormProps) {
  const { toast } = useToast();
  
  const form = useForm<MeasurementsFormValues>({
    resolver: zodResolver(measurementsSchema),
    defaultValues: {
      gender: "",
      age: "",
      height: "",
      weight: "",
      chest: "",
      waist: "",
      hips: "",
      shoulderWidth: "",
      armLength: "",
      inseam: "",
    },
  });

  const measurementsMutation = useMutation({
    mutationFn: async (data: MeasurementsFormValues) => {
      return apiRequest("POST", "/api/measurements", data);
    },
    onSuccess: () => {
      toast({
        title: "Measurements saved",
        description: "Your measurements have been saved successfully.",
      });
      onContinue();
    },
    onError: (error) => {
      toast({
        title: "Error saving measurements",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: MeasurementsFormValues) => {
    measurementsMutation.mutate(data);
  };

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-[#2C3E50] text-center mb-8">
          Enter Your Measurements
        </h2>

        <div className="max-w-2xl mx-auto bg-[#F8F9FA] rounded-xl shadow-md p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Information */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-poppins font-medium text-[#2C3E50] mb-4">
                  Basic Information
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Gender</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="non-binary">Non-binary</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Age</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Your age"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="height"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Height (cm)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Height in cm"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="weight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Weight (kg)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Weight in kg"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Detailed Measurements */}
              <div className="md:col-span-2">
                <h3 className="text-lg font-poppins font-medium text-[#2C3E50] mb-4">
                  Detailed Measurements (in cm)
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="chest"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Chest</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Chest"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="waist"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Waist</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Waist"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hips"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Hips</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Hips"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="shoulderWidth"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Shoulder Width</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Shoulder width"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="armLength"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Arm Length</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Arm length"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="inseam"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-medium text-[#34495E]">Inseam</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="Inseam"
                            {...field}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="md:col-span-2 text-center mt-4">
                <Button
                  type="submit"
                  className="px-8 py-2 bg-[#3498DB] text-white font-medium rounded-full hover:bg-blue-600 transition-colors"
                  disabled={measurementsMutation.isPending}
                >
                  {measurementsMutation.isPending ? "Processing..." : "Generate Virtual Model"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
