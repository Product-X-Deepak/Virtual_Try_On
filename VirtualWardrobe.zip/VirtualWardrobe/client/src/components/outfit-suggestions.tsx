import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
  description: string;
  category: string;
}

interface OutfitSuggestionsProps {
  suggestions: Product[] | undefined;
  isLoading: boolean;
  onTryOn: (product: Product) => void;
}

export default function OutfitSuggestions({ 
  suggestions, 
  isLoading, 
  onTryOn 
}: OutfitSuggestionsProps) {
  const { toast } = useToast();

  const handleAddToCart = (product: Product) => {
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  return (
    <div className="mt-12 bg-white rounded-xl shadow-md p-6">
      <div className="flex items-center mb-6">
        <div className="w-1 h-6 bg-[#E74C3C] rounded mr-3"></div>
        <h3 className="text-xl font-poppins font-semibold text-[#2C3E50]">
          Complete Your Look
        </h3>
      </div>
      <p className="text-[#34495E] mb-6">
        We've picked these items to complement your style. Try them on or add them to your cart.
      </p>
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <CardContent className="p-3">
                <Skeleton className="h-4 w-3/4 my-1" />
                <Skeleton className="h-3 w-1/4 my-1" />
                <div className="flex justify-between mt-2">
                  <Skeleton className="h-8 w-2/5" />
                  <Skeleton className="h-8 w-2/5" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {suggestions?.map((product) => (
            <Card key={product.id} className="bg-white rounded-lg shadow overflow-hidden">
              <div className="w-full h-48">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <CardContent className="p-3">
                <h4 className="text-sm font-medium text-[#2C3E50]">{product.name}</h4>
                <p className="text-xs text-gray-500">{product.price}</p>
                <div className="flex justify-between mt-2">
                  <Button
                    className="px-3 py-1.5 bg-[#E74C3C] text-white text-xs font-medium rounded-full hover:bg-red-600 transition-all hover:scale-105"
                    onClick={() => onTryOn(product)}
                  >
                    Try On
                  </Button>
                  <Button
                    className="px-3 py-1.5 bg-white border border-[#3498DB] text-[#3498DB] text-xs font-medium rounded-full hover:bg-blue-50 transition-all hover:scale-105"
                    onClick={() => handleAddToCart(product)}
                  >
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
