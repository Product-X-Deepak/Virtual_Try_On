import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
  description: string;
  category: string;
}

interface ProductSelectionProps {
  products: Product[] | undefined;
  isLoading: boolean;
  onTryOn: (product: Product) => void;
}

export default function ProductSelection({ 
  products, 
  isLoading, 
  onTryOn 
}: ProductSelectionProps) {
  const [activeCategory, setActiveCategory] = useState("tops");

  const filteredProducts = products?.filter(
    product => product.category === activeCategory
  );

  return (
    <div className="bg-[#F8F9FA] rounded-xl shadow-md p-6 lg:col-span-1">
      <h3 className="text-xl font-poppins font-medium text-[#2C3E50] mb-4">
        Select Items
      </h3>

      {/* Category Tabs */}
      <Tabs defaultValue="tops" onValueChange={setActiveCategory}>
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="tops">Tops</TabsTrigger>
          <TabsTrigger value="bottoms">Bottoms</TabsTrigger>
          <TabsTrigger value="dresses">Dresses</TabsTrigger>
          <TabsTrigger value="accessories">Accessories</TabsTrigger>
        </TabsList>

        <TabsContent value={activeCategory}>
          {isLoading ? (
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-40 w-full" />
                  <CardContent className="p-2">
                    <Skeleton className="h-4 w-3/4 my-1" />
                    <Skeleton className="h-3 w-1/4 my-1" />
                    <Skeleton className="h-8 w-full mt-2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {filteredProducts?.map((product) => (
                <Card key={product.id} className="bg-white rounded-lg shadow overflow-hidden cursor-pointer hover:shadow-md transition-shadow">
                  <div className="w-full h-40">
                    <img 
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-2">
                    <h4 className="text-sm font-medium text-[#2C3E50]">{product.name}</h4>
                    <p className="text-xs text-gray-500">{product.price}</p>
                    <Button
                      className="mt-2 w-full px-2 py-1.5 bg-[#E74C3C] text-white text-xs font-medium rounded-full hover:bg-red-600 transition-all hover:scale-105"
                      onClick={() => onTryOn(product)}
                    >
                      Try On
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
