import { useState } from "react";
import { useLocation } from "wouter";
import TryOnOptions from "@/components/try-on-options";
import PhotoUpload from "@/components/photo-upload";
import MeasurementsForm from "@/components/measurements-form";
import CombinedApproach from "@/components/combined-approach";

export default function Home() {
  const [, setLocation] = useLocation();
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const handleOptionSelect = (optionType: string) => {
    setActiveSection(optionType);
  };

  const handleContinue = () => {
    setLocation("/try-on");
  };

  return (
    <div className="bg-[#F8F9FA]">
      {/* Hero Section */}
      <div className="bg-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl md:text-4xl font-poppins font-bold text-[#2C3E50]">
              Virtual Fitting Room
            </h1>
            <p className="mt-4 text-lg text-[#34495E] max-w-3xl mx-auto">
              Try before you buy with our AI-powered virtual fitting room. See how clothes look on you without the hassle of physical fitting rooms.
            </p>
            <div className="mt-8">
              <a
                href="#try-on-options"
                className="inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-full text-white bg-[#3498DB] hover:bg-blue-600 shadow-md transition duration-150 ease-in-out"
              >
                Try On Now
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Try-On Options */}
      {!activeSection && (
        <div id="try-on-options">
          <TryOnOptions onSelect={handleOptionSelect} />
        </div>
      )}

      {/* Conditional Render of Selected Method */}
      {activeSection === "photo" && (
        <PhotoUpload onContinue={handleContinue} />
      )}
      {activeSection === "measurements" && (
        <MeasurementsForm onContinue={handleContinue} />
      )}
      {activeSection === "combined" && (
        <CombinedApproach onContinue={handleContinue} />
      )}
    </div>
  );
}
