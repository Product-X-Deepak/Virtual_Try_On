import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import ProductSelection from "@/components/product-selection";
import TryOnPreview from "@/components/try-on-preview";
import OutfitSuggestions from "@/components/outfit-suggestions";

// Define Product interface to match other components
interface Product {
  id: number;
  name: string;
  price: string;
  image: string;
  description: string;
  category: string;
}

export default function VirtualTryOn() {
  const [selectedItem, setSelectedItem] = useState<Product | null>(null);

  // Fetch product data with proper typing
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  // Fetch suggestions data with proper typing
  const { data: suggestions, isLoading: suggestionsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/suggestions"],
  });

  const handleTryOn = (product: Product) => {
    setSelectedItem(product);
  };

  return (
    <div className="py-12 bg-[#F8F9FA] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-[#2C3E50] text-center mb-8">
          Virtual Try-On Experience
        </h2>
        <p className="text-center text-[#34495E] mb-8 max-w-2xl mx-auto">
          Try on clothing virtually with our advanced fitting room. Select items from our collection and see how they look on your virtual model.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Product Selection */}
          <ProductSelection 
            products={products} 
            isLoading={productsLoading} 
            onTryOn={handleTryOn} 
          />

          {/* Center Column - Virtual Try-On Viewer */}
          <div className="lg:col-span-2">
            <TryOnPreview selectedItem={selectedItem} />
          </div>
        </div>

        {/* Outfit Suggestions */}
        <OutfitSuggestions 
          suggestions={suggestions} 
          isLoading={suggestionsLoading} 
          onTryOn={handleTryOn} 
        />
      </div>
    </div>
  );
}
