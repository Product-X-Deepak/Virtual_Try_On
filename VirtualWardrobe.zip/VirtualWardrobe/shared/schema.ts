import { pgTable, text, serial, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define Product schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: text("price").notNull(),
  image: text("image").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
});

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// Define User Measurements schema
export const userMeasurements = pgTable("user_measurements", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  gender: text("gender").notNull(),
  age: integer("age"),
  height: integer("height").notNull(),
  weight: integer("weight").notNull(),
  chest: integer("chest").notNull(),
  waist: integer("waist").notNull(),
  hips: integer("hips").notNull(),
  shoulderWidth: integer("shoulder_width"),
  armLength: integer("arm_length"),
  inseam: integer("inseam"),
  createdAt: text("created_at").notNull(),
});

export const insertUserMeasurementsSchema = createInsertSchema(userMeasurements).omit({
  id: true,
});

export type InsertUserMeasurements = z.infer<typeof insertUserMeasurementsSchema>;
export type UserMeasurements = typeof userMeasurements.$inferSelect;

// Define User Photos schema
export const userPhotos = pgTable("user_photos", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  photoPath: text("photo_path").notNull(),
  createdAt: text("created_at").notNull(),
});

export const insertUserPhotoSchema = createInsertSchema(userPhotos).omit({
  id: true,
});

export type InsertUserPhoto = z.infer<typeof insertUserPhotoSchema>;
export type UserPhoto = typeof userPhotos.$inferSelect;

// Define Virtual Models schema
export const virtualModels = pgTable("virtual_models", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull().unique(),
  modelPath: text("model_path").notNull(),
  modelType: text("model_type").notNull(), // 'photo', 'measurements', or 'combined'
  createdAt: text("created_at").notNull(),
});

export const insertVirtualModelSchema = createInsertSchema(virtualModels).omit({
  id: true,
});

export type InsertVirtualModel = z.infer<typeof insertVirtualModelSchema>;
export type VirtualModel = typeof virtualModels.$inferSelect;

// Define Size Recommendations schema
export const sizeRecommendations = pgTable("size_recommendations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  productId: integer("product_id").notNull(),
  size: text("size").notNull(), // XS, S, M, L, XL, XXL
  confidence: integer("confidence").notNull(), // 0-100
  createdAt: text("created_at").notNull(),
});

export const insertSizeRecommendationSchema = createInsertSchema(sizeRecommendations).omit({
  id: true, 
});

export type InsertSizeRecommendation = z.infer<typeof insertSizeRecommendationSchema>;
export type SizeRecommendation = typeof sizeRecommendations.$inferSelect;
